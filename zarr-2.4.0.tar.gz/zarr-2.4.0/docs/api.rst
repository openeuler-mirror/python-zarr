API reference
=============

.. toctree::
    :maxdepth: 3

    api/creation
    api/core
    api/hierarchy
    api/storage
    api/n5
    api/convenience
    api/codecs
    api/attrs
    api/sync
