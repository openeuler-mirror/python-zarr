Array creation (``zarr.creation``)
==================================
.. module:: zarr.creation
.. autofunction:: create
.. autofunction:: empty
.. autofunction:: zeros
.. autofunction:: ones
.. autofunction:: full
.. autofunction:: array
.. autofunction:: open_array
.. autofunction:: empty_like
.. autofunction:: zeros_like
.. autofunction:: ones_like
.. autofunction:: full_like
.. autofunction:: open_like
