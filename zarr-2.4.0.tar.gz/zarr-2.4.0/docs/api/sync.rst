Synchronization (``zarr.sync``)
===============================
.. module:: zarr.sync

.. autoclass:: ThreadSynchronizer
.. autoclass:: ProcessSynchronizer
