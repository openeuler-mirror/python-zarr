The Attributes class (``zarr.attrs``)
=====================================
.. module:: zarr.attrs

.. autoclass:: Attributes

    .. automethod:: __getitem__
    .. automethod:: __setitem__
    .. automethod:: __delitem__
    .. automethod:: __iter__
    .. automethod:: __len__
    .. automethod:: keys
    .. automethod:: asdict
    .. automethod:: put
    .. automethod:: update
    .. automethod:: refresh
