Convenience functions (``zarr.convenience``)
============================================
.. automodule:: zarr.convenience
.. autofunction:: open
.. autofunction:: save
.. autofunction:: load
.. autofunction:: save_array
.. autofunction:: save_group
.. autofunction:: copy
.. autofunction:: copy_all
.. autofunction:: copy_store
.. autofunction:: tree
.. autofunction:: consolidate_metadata
.. autofunction:: open_consolidated
