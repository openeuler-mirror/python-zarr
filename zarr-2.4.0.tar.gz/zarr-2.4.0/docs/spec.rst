.. _spec:

Specifications
==============

.. toctree::
    :maxdepth: 3

    spec/v1
    spec/v2
