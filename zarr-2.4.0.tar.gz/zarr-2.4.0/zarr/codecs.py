# -*- coding: utf-8 -*-
# flake8: noqa
from numcodecs import *
from numcodecs.registry import codec_registry
